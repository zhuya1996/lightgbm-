# LGBM_demonstration
A simple script demonstrate how to use GridSearchCV with LightGBM(LGBM) and early stopping
